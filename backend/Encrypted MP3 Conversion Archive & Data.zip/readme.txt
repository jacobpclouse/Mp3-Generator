Hi there! If you are reading this, you have just converted a file using my mp3 conveter! 
Thank you for your support!


All of these files are encrypted and you will need to decrypt them with the key you were sent and the decrypt.py 
program included with this read me.

1) Make sure that you put the decrypt.py and the encrypted MP3 in the same folder. DO NOT RENAME IT!

2) Make sure you have the key that was sent to you for this file, create a file called 'mykey.key' and enter in your key.

3) Open up a terminal (or terminal emulator like Git BASH) and run "python3 decrypt.py". 
    (if you don't have Fernet installed, you can install it by usining "pip install Fernet")

4) The program should output a decrypted version of your file called "decryptedMessage.mp3", you are all set!